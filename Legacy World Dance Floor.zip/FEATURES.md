# Feature status: all 355 items

**Done: 225** · **Partial: 74** · **Needs a server you host: 7** · **Not built: 49**

Numbers match your wishlist. "Done" means it is built and, where I could test it here, it passed my scripted tests in the running app (65 UI checks, system checks, and relay checks). A few "Done" items need Windows hardware or your actual game and could not be exercised on my machine: tray icon, start with Windows, Kinect status, game launching, the overlay on top of the real game, and reading real game fonts. Report any that misbehave. "Partial" explains the limit. Nothing here talks to a server unless you run `server/relay.js` yourself; offline, the worldwide dancers and counts are simulated.

## World Dance Floor and multiplayer (1-35)
- **Done:** 1, 3, 5-6, 9-13, 17-19, 21-22, 25-29, 31-32, 35
- **Partial #2:** title-box OCR works once you draw a box on the shared game window; accuracy on the real game fonts is untested
- **Partial #4:** built-in titles for 29 Just Dance 2017 songs, plus imports and learned aliases; other songs show a cleaned-up codename
- **Partial #7:** simulated offline; real counts only inside LAN or relay rooms
- **Partial #8:** join animations yes; leaving shows a toast
- **Partial #14:** rotating globe with player countries lit up (not a flat map)
- **Partial #15:** simulated counts
- **Partial #16:** friend list works; online status only inside your current room
- **Partial #30:** empty slots fill with ghosts matched to your rank; no real-player matchmaking
- **Needs your relay #20:** relay server you host
- **Not built:** #23 host migration; #24 spectator mode; #33 vote for next song; #34 practice rooms

## Songs and music library (36-70)
- **Done:** 46, 48-53, 57-59, 61, 63-70
- **Partial #36:** through the song-title box (see 2)
- **Partial #37:** through the song-title box
- **Partial #38:** through the song-title box if the title is shown on that screen
- **Partial #39:** 29 built-in titles plus import
- **Partial #40:** built-in and imported only
- **Partial #42:** from imported metadata only
- **Partial #43:** learned after your first play of a song
- **Partial #44:** from imported metadata only
- **Partial #45:** from imported metadata only
- **Partial #47:** favorites, unplayed and excluded filters; no difficulty, genre or year filters
- **Partial #54:** playlist queue; no multi-user requests
- **Partial #55:** daily challenge includes dancing a new song; no dedicated random-challenge mode
- **Partial #56:** per-song personal boards plus the relay's top list
- **Partial #60:** LAN shows each player's song count, not per song
- **Not built:** #41 cover art; #62 alternate versions and mashups

## Gameplay and in-game overlay (71-95)
- **Done:** 71-79, 81-82, 84-85, 87-90, 92, 94-95
- **Partial #83:** highlight color only
- **Partial #86:** overlay only appears during a match
- **Partial #93:** avatars in the app leaderboard, flags in the overlay
- **Not built:** #80 combo or streak (the game does not expose it); #91 custom player order

## Results and celebrations (96-120)
- **Done:** 96-110, 113-115, 117-120
- **Partial #111:** plays, best score and last played per song
- **Partial #112:** compare against an exported profile file
- **Partial #116:** short jingles only

## XP, levels and achievements (121-150)
- **Done:** 121-128, 131-133, 135-146, 148, 150
- **Needs your relay #129:** relay top list
- **Not built:** #130 friends leaderboard; #134 country leaderboards; #147 favorite genre statistic; #149 most-improved-player statistic

## Events and social (151-175)
- **Done:** 151-153, 155-159, 163, 166, 175
- **Partial #154:** local points only
- **Partial #160:** daily and weekly challenges, local
- **Partial #164:** weekend tournament points only
- **Partial #165:** seasonal app backgrounds, not lobby-specific
- **Partial #167:** through LAN rematches
- **Partial #168:** through LAN matches
- **Partial #171:** results screen only
- **Not built:** #161 global participation goals (needs a server); #162 community milestones (needs a server); #169 best-of-three; #170 tournament brackets; #172 custom event schedules; #173 private tournament hosting; #174 community song voting

## Profiles and customization (176-200)
- **Done:** 176-179, 181-184, 186-192, 194-197, 199-200
- **Partial #180:** accessories unlock through events
- **Partial #198:** idle bobbing only
- **Not built:** #185 favorite genre on profile; #193 profile privacy settings

## Just Dance 2017 and Kinect (201-220)
- **Done:** 202, 204-207, 209-210, 212-213, 216-218
- **Partial #201:** Windows hardware query, untested with a real sensor
- **Partial #203:** same query as 201
- **Partial #208:** overlay opens with each match; you share the game window once
- **Partial #211:** overlay works over borderless windows; that is a game setting
- **Partial #219:** memory usage only
- **Not built:** #214 launching into the separate launcher; #215 window layout restore; #220 compatibility checks after updates

## Launcher and quality of life (221-250)
- **Done:** 221-230, 232-241, 243-244, 247, 249
- **Partial #231:** works if the app is in the game folder or the default install path
- **Partial #242:** shows game and LAN status
- **Partial #246:** your data is backed up on version change; no installer rollback
- **Partial #248:** errors are logged; no automatic restart
- **Partial #250:** reduce motion and light theme only
- **Not built:** #245 update checker (needs a place to host updates)

## Online infrastructure (251-275)
- **Done:** 257-258, 260-261, 265-266, 268, 270
- **Partial #256:** shared clock plus the start message
- **Partial #259:** ping time only
- **Partial #262:** profile is local; scores can be submitted to your relay
- **Partial #263:** relay has a /health page; no in-app indicator
- **Partial #264:** basic sanity checks, not real anti-cheat
- **Partial #267:** shows a warning only
- **Partial #269:** Diagnostics shows peers and latency
- **Partial #274:** relay /health counts only
- **Needs your relay #251:** relay included, you host it
- **Needs your relay #252:** relay rooms
- **Needs your relay #253:** relay room passwords
- **Needs your relay #272:** relay rooms
- **Needs your relay #273:** relay capacity limits
- **Not built:** #254 secure identity and accounts; #255 server-authoritative song choice; #271 server configuration panel; #275 server match history

## Automation and smart tools (276-295)
- **Done:** 280-282, 284-285, 287-290, 295
- **Partial #276:** same as 2
- **Partial #283:** 29 built-in titles, learned aliases, and import
- **Partial #286:** pauses when window sharing stops
- **Partial #294:** live score reading plus a confirm-your-final-score popup
- **Not built:** #277 detect song-selection screens; #278 detect loading screens; #279 detect results screens; #291 recognize game state; #292 detect song end; #293 detect return to song selection

## Visual polish (296-315)
- **Done:** 296-298, 300-302, 304, 306-308, 310-312, 314-315
- **Partial #299:** subtle wave only
- **Partial #303:** count-up on results only
- **Partial #305:** procedural ambient tune only
- **Partial #313:** tab fade only
- **Not built:** #309 cover-art transitions

## Development and maintenance (316-335)
- **Done:** 316, 318, 323-330, 333-334
- **Partial #317:** tests use rendered text, not saved screenshots
- **Partial #319:** not automated
- **Partial #320:** synthetic messages plus relay tests, not two real clients
- **Partial #322:** tested with a fake game folder
- **Partial #331:** restores data only, not program files
- **Partial #332:** memory usage only
- **Partial #335:** tested over loopback only
- **Not built:** #321 results screenshot tests

## Extra ideas (336-355)
- **Done:** 339-340, 347, 353
- **Partial #336:** endless random mode with no leave condition
- **Partial #342:** emotes only
- **Partial #349:** personal-best pace indicator, no ghost row
- **Partial #355:** host a room and share its code
- **Not built:** #337 last dancer standing; #338 rival system; #341 country-versus-country events; #343 mystery song rounds; #344 throwback events; #345 personal dance journal; #346 custom lobby announcements; #348 boss challenge; #350 community hall of fame; #351 lobby population history; #352 custom victory poses; #354 friend activity feed

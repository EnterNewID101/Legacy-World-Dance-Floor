// World Dance Floor relay server (optional, self-hosted).
// Run:  node server/relay.js [port] [--maxroom=16]      Health: http://host:(port+1)/health
// Players connect from the app's LAN tab > "Online server". Forward the TCP port on your router for friends outside your home.
const net = require('net'), http = require('http'), fs = require('fs'), path = require('path');
const PORT = +(process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : 47800);
const MAXROOM = +((process.argv.find(a => a.startsWith('--maxroom=')) || '=16').split('=')[1]);
const MAXMSG = 60;            // messages per second per client
const VERSION = 1;
const rooms = new Map();      // code -> {pass, members:Set, created}
const LB_FILE = path.join(__dirname, 'leaderboard.json');
let lb = {}; try { lb = JSON.parse(fs.readFileSync(LB_FILE, 'utf8')); } catch (e) {}
const saveLb = () => { try { fs.writeFileSync(LB_FILE, JSON.stringify(lb)); } catch (e) {} };
const send = (s, o) => { try { s.write(JSON.stringify(o) + '\n'); } catch (e) {} };
const okCode = c => typeof c === 'string' && /^[A-Za-z0-9]{2,12}$/.test(c);
const clean = s => String(s || '').replace(/[<>&"'`]/g, '').slice(0, 16);
const stats = { connections: 0, messages: 0, started: Date.now() };

const server = net.createServer(s => {
  stats.connections++;
  let buf = '', room = null, count = 0, win = Date.now();
  s.setNoDelay(true); s.on('error', () => {});
  s.on('close', () => { if (room) { room.members.delete(s); if (!room.members.size) rooms.delete(room.code); } });
  s.on('data', d => {
    buf += d; if (buf.length > 65536) return s.destroy();
    let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); let msg; try { msg = JSON.parse(line); } catch (e) { continue; }
      const now = Date.now(); if (now - win > 1000) { win = now; count = 0; } if (++count > MAXMSG) continue;   // rate limit
      stats.messages++; handle(msg); }
  });
  function handle(msg) {
    if (!msg || typeof msg.t !== 'string') return;
    if (msg.t === 'join') {
      if (room) return; const code = msg.room;
      if (!okCode(code)) return send(s, { t: 'deny', why: 'bad room code' });
      let r = rooms.get(code);
      if (!r) { if (!msg.create) return send(s, { t: 'deny', why: 'room not found' }); r = { code, pass: String(msg.pass || ''), members: new Set(), created: Date.now() }; rooms.set(code, r); }
      else if (r.pass && r.pass !== String(msg.pass || '')) return send(s, { t: 'deny', why: 'wrong password' });
      if (r.members.size >= MAXROOM) return send(s, { t: 'deny', why: 'room is full' });
      r.members.add(s); room = r; return send(s, { t: 'joined', room: code, members: r.members.size, v: VERSION });
    }
    if (msg.t === 'lb') { const song = clean(msg.song) || '*'; const top = Object.entries(lb[song] || {}).sort((a, b) => b[1] - a[1]).slice(0, 20); return send(s, { t: 'lb', song, top }); }
    if (msg.t === 'submit') {   // basic sanity checks, not real anti-cheat
      const sc = Math.round(+msg.score), mx = Math.round(+msg.max), name = clean(msg.name), song = clean(msg.song) || '*';
      if (!name || !(sc >= 0) || !(mx > 0 && mx <= 20000) || sc > mx) return send(s, { t: 'rejected', why: 'invalid score' });
      for (const k of [song, '*']) { lb[k] = lb[k] || {}; if (!(lb[k][name] >= sc)) lb[k][name] = sc; }
      saveLb(); return send(s, { t: 'accepted' });
    }
    if (msg.t === 'status') return send(s, { t: 'status', rooms: rooms.size, uptime: Math.round((Date.now() - stats.started) / 1000), v: VERSION });
    if (room) room.members.forEach(o => o !== s && send(o, msg));   // relay to everyone else in the room
  }
});
server.listen(PORT, () => console.log('relay listening on ' + PORT));
http.createServer((q, r) => { r.setHeader('content-type', 'application/json'); r.end(JSON.stringify({ ok: true, rooms: rooms.size, players: [...rooms.values()].reduce((a, x) => a + x.members.size, 0), ...stats })); }).listen(PORT + 1);
module.exports = server;
